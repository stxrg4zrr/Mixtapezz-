#!/usr/bin/env bash
# Generates the Android platform folder and applies: manifest (background audio),
# adaptive icon, dark splash screen, packages.
set -e

# Make every plugin compile against a recent Android SDK.
mkdir -p ~/.gradle/init.d
cat > ~/.gradle/init.d/sdk.gradle <<'GRADLE'
allprojects {
  afterEvaluate { p ->
    def a = p.extensions.findByName('android')
    if (a != null) {
      a.compileSdk = 36
      try { a.lint.checkReleaseBuilds = false } catch (Throwable ignored) {}
      try { a.lint.abortOnError = false } catch (Throwable ignored) {}
    }
  }
}
GRADLE

if [ ! -d android ]; then
  flutter create --org com.mixtape --project-name mixtape_deck --platforms=android _gen
  cp -r _gen/android ./android
  rm -rf _gen
fi

cat > android/app/src/main/AndroidManifest.xml <<'XML'
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <application
        android:label="Tape Eater"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <service
            android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>
        <receiver
            android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
    <queries>
        <intent>
            <action android:name="android.intent.action.PROCESS_TEXT"/>
            <data android:mimeType="text/plain"/>
        </intent>
    </queries>
</manifest>
XML

find android/app/src/main -name 'MainActivity.*' -delete
mkdir -p android/app/src/main/kotlin/com/mixtape/mixtape_deck
cat > android/app/src/main/kotlin/com/mixtape/mixtape_deck/MainActivity.kt <<'KT'
package com.mixtape.mixtape_deck

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
KT

# Turn off Android's release "lint vital" check (it crashed the build; it is not needed for an APK).
for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ] && ! grep -q "checkReleaseBuilds" "$f"; then
    cat >> "$f" <<'LINT'

android {
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
LINT
  fi
done

flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create

echo ""
echo "Done. Now run:  flutter build apk --release"
