import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../utils.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key, required this.item});

  final TrackRef item;

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  late final VideoPlayerController _c;
  bool _controls = true;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    context.read<PlayerController>().pause();
    _c = VideoPlayerController.file(File(widget.item.track.path));
    _c.addListener(() {
      if (mounted) setState(() {});
    });
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _c.play();
    }).catchError((Object _) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = _c.value;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _controls = !_controls),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Center(
              child: _failed
                  ? const Text('Can\'t play this video',
                      style: TextStyle(color: kMuted))
                  : (v.isInitialized
                      ? AspectRatio(
                          aspectRatio: v.aspectRatio,
                          child: VideoPlayer(_c),
                        )
                      : const CircularProgressIndicator(color: kOrange)),
            ),
            if (_controls)
              SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        Expanded(
                          child: Text(
                            widget.item.track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                    if (v.isInitialized)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            VideoProgressIndicator(
                              _c,
                              allowScrubbing: true,
                              colors: const VideoProgressColors(
                                playedColor: kOrange,
                                bufferedColor: Colors.white24,
                                backgroundColor: Colors.white12,
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            Row(
                              children: [
                                Text(fmtDuration(v.position),
                                    style: const TextStyle(color: kMuted)),
                                const Spacer(),
                                IconButton(
                                  iconSize: 44,
                                  color: kOrange,
                                  icon: Icon(v.isPlaying
                                      ? Icons.pause_circle_filled
                                      : Icons.play_circle_fill),
                                  onPressed: () =>
                                      v.isPlaying ? _c.pause() : _c.play(),
                                ),
                                const Spacer(),
                                Text(fmtDuration(v.duration),
                                    style: const TextStyle(color: kMuted)),
                              ],
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
