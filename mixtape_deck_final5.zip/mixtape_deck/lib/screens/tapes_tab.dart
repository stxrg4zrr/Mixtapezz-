import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/alphabet_bar.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import 'album_screen.dart';

const double _rowH = 72;
const double _pinnedBlock = 120; // 30 gap + 90 tiles
const double _headerWithPinned = 90;
const double _headerNoPinned = 52;

class TapesTab extends StatefulWidget {
  const TapesTab({super.key});

  @override
  State<TapesTab> createState() => _TapesTabState();
}

class _TapesTabState extends State<TapesTab> {
  final ScrollController _sc = ScrollController();
  final ValueNotifier<bool> _barVisible = ValueNotifier<bool>(false);
  Timer? _hideTimer;
  bool _dragging = false;
  String? _bubble;

  @override
  void dispose() {
    _hideTimer?.cancel();
    _sc.dispose();
    _barVisible.dispose();
    super.dispose();
  }

  // The A-Z bar only shows while the list is moving (or while you hold it).
  void _showBar() {
    _hideTimer?.cancel();
    if (!_barVisible.value) _barVisible.value = true;
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(milliseconds: 1100), () {
      if (!_dragging) _barVisible.value = false;
    });
  }

  bool _onScroll(ScrollNotification n) {
    if (n.metrics.axis != Axis.vertical) return false;
    if (n is ScrollStartNotification || n is ScrollUpdateNotification) {
      _showBar();
      _scheduleHide();
    } else if (n is ScrollEndNotification) {
      _scheduleHide();
    }
    return false;
  }

  void _jump(String letter, List<Album> albums, bool hasPinned, LibraryStore store) {
    _dragging = true;
    _showBar();
    if (_bubble != letter) setState(() => _bubble = letter);
    if (albums.isEmpty || !_sc.hasClients) return;
    final target = letter == '#' ? 0 : letter.codeUnitAt(0) - 64;
    var best = 0;
    var bestD = 1 << 30;
    for (var i = 0; i < albums.length; i++) {
      final l = letterOf(store.keyOf(albums[i]));
      final code = l == '#' ? 0 : l.codeUnitAt(0) - 64;
      final d = (code - target).abs();
      if (d < bestD) {
        bestD = d;
        best = i;
        if (d == 0) break;
      }
    }
    final double base =
        hasPinned ? (_pinnedBlock + _headerWithPinned) : _headerNoPinned;
    final double off = base + best * _rowH;
    _sc.jumpTo(math.min(off, _sc.position.maxScrollExtent));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final albums = store.albums;
    final pinned = store.pinned;
    final hasPinned = pinned.isNotEmpty;

    if (store.count == 0) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'Your deck is empty.\nTap + and pick a .zip mixtape.',
            textAlign: TextAlign.center,
            style: TextStyle(color: kMuted, fontSize: 16, height: 1.6),
          ),
        ),
      );
    }

    return Stack(
      children: [
        Positioned.fill(
          child: NotificationListener<ScrollNotification>(
            onNotification: _onScroll,
            child: CustomScrollView(
              controller: _sc,
              slivers: [
                if (hasPinned)
                  SliverToBoxAdapter(
                    child: SizedBox(
                      height: _pinnedBlock,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 30),
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          itemCount: pinned.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (_, i) => _PinnedTile(album: pinned[i]),
                        ),
                      ),
                    ),
                  ),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: hasPinned ? _headerWithPinned : _headerNoPinned,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(13, hasPinned ? 30 : 2, 12, 0),
                      child: SizedBox(
                        height: 48,
                        child: Row(
                          children: [
                            const Text('All',
                                style: TextStyle(
                                    fontSize: 19, fontWeight: FontWeight.w700)),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.filter_list_rounded),
                              onPressed: () => _showSort(context, store),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (albums.isEmpty)
                  const SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(
                        child: Text('No tapes match.', style: TextStyle(color: kMuted)),
                      ),
                    ),
                  )
                else
                  SliverFixedExtentList(
                    itemExtent: _rowH,
                    delegate: SliverChildBuilderDelegate(
                      (c, i) => _AlbumRow(album: albums[i]),
                      childCount: albums.length,
                    ),
                  ),
                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ),
          ),
        ),
        if (albums.length > 1)
          Positioned(
            right: 8,
            top: 0,
            bottom: 110,
            child: ValueListenableBuilder<bool>(
              valueListenable: _barVisible,
              builder: (context, visible, child) => IgnorePointer(
                ignoring: !visible,
                child: AnimatedOpacity(
                  opacity: visible ? 1 : 0,
                  duration: const Duration(milliseconds: 220),
                  child: child,
                ),
              ),
              child: AlphabetBar(
                onLetter: (l) => _jump(l, albums, hasPinned, store),
                onEnd: () {
                  _dragging = false;
                  _scheduleHide();
                  if (mounted) setState(() => _bubble = null);
                },
              ),
            ),
          ),
        if (_bubble != null)
          Center(
            child: Container(
              width: 64,
              height: 64,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: Color(0xE6262626),
                shape: BoxShape.circle,
              ),
              child: Text(_bubble!,
                  style: const TextStyle(
                      fontSize: 30, fontWeight: FontWeight.w800, color: kChipOrange)),
            ),
          ),
      ],
    );
  }

  void _showSort(BuildContext context, LibraryStore store) {
    Widget opt(SortMode m, String label) => ListTile(
          title: Text(label),
          trailing: store.sort == m
              ? const Icon(Icons.check_rounded, color: kOrange)
              : null,
          onTap: () {
            store.setSort(m);
            Navigator.pop(context);
          },
        );
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Sort tapes',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            opt(SortMode.titleAsc, 'Title  A to Z'),
            opt(SortMode.titleDesc, 'Title  Z to A'),
            opt(SortMode.artistAsc, 'Artist  A to Z'),
            opt(SortMode.newest, 'Recently added'),
          ],
        ),
      ),
    );
  }
}

class _PinnedTile extends StatelessWidget {
  const _PinnedTile({required this.album});

  final Album album;

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerController>();
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => AlbumScreen(album: album))),
      onLongPress: () => showAlbumMenu(context, album),
      child: SizedBox(
        width: 90,
        height: 90,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CoverImage(path: album.coverPath, cacheWidth: 300),
              Positioned(
                left: 6,
                bottom: 6,
                child: GestureDetector(
                  onTap: () => player.playAlbum(album, 0),
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: const Color(0xB3000000),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AlbumRow extends StatefulWidget {
  const _AlbumRow({required this.album});

  final Album album;

  @override
  State<_AlbumRow> createState() => _AlbumRowState();
}

class _AlbumRowState extends State<_AlbumRow> {
  static const double _open = 120; // width of the two action tiles
  double _dx = 0;
  bool _dragging = false;

  void _close() => setState(() => _dx = 0);

  @override
  Widget build(BuildContext context) {
    final album = widget.album;
    final store = context.read<LibraryStore>();
    final player = context.read<PlayerController>();
    final dur = _dragging ? Duration.zero : const Duration(milliseconds: 180);

    return ClipRect(
      child: Stack(
        children: [
          // Swipe actions: pin + play (slide in from the left).
          Positioned(
            left: 0,
            top: 6,
            width: _open,
            height: 60,
            child: AnimatedContainer(
              duration: dur,
              transform: Matrix4.translationValues(_dx * 1.1 - _open, 0, 0),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        store.togglePin(album);
                        _close();
                      },
                      child: Container(
                        decoration: const BoxDecoration(
                          color: kAmber,
                          borderRadius: BorderRadius.horizontal(
                              left: Radius.circular(12)),
                        ),
                        child: Icon(
                          album.pinned ? Icons.push_pin_outlined : Icons.push_pin,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        player.playAlbum(album, 0);
                        _close();
                      },
                      child: Container(
                        decoration: const BoxDecoration(
                          color: kChipOrange,
                          borderRadius: BorderRadius.horizontal(
                              right: Radius.circular(12)),
                        ),
                        child: const Icon(Icons.play_arrow_rounded,
                            color: Colors.white, size: 30),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // The row itself.
          Positioned.fill(
            child: AnimatedContainer(
              duration: dur,
              transform: Matrix4.translationValues(_dx, 0, 0),
              child: GestureDetector(
                onHorizontalDragStart: (_) => setState(() => _dragging = true),
                onHorizontalDragUpdate: (d) => setState(() {
                  _dx = (_dx + d.delta.dx).clamp(0.0, _open + 20).toDouble();
                }),
                onHorizontalDragEnd: (d) => setState(() {
                  _dragging = false;
                  final v = d.primaryVelocity ?? 0;
                  _dx = (v > 700 || (_dx > _open / 2 && v > -700)) ? _open : 0;
                }),
                onHorizontalDragCancel: () => setState(() {
                  _dragging = false;
                  _dx = _dx > _open / 2 ? _open : 0;
                }),
                child: InkWell(
                  onTap: () {
                    if (_dx > 0) {
                      _close();
                      return;
                    }
                    Navigator.of(context).push(MaterialPageRoute<void>(
                        builder: (_) => AlbumScreen(album: album)));
                  },
                  onLongPress: () => showAlbumMenu(context, album),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 6, 50, 6),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: SizedBox(
                            width: 60,
                            height: 60,
                            child: CoverImage(path: album.coverPath, cacheWidth: 200),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                album.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 19, height: 1.1),
                              ),
                              Text(
                                album.artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 15, color: kRowMuted),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
