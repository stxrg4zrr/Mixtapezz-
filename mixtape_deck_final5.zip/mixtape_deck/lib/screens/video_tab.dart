import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import 'video_screen.dart';

class VideoTab extends StatelessWidget {
  const VideoTab({super.key});

  @override
  Widget build(BuildContext context) {
    final videos = context.watch<LibraryStore>().videos;

    if (videos.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'No videos yet.\nTapes with .mp4 or .mov files show up here.',
            textAlign: TextAlign.center,
            style: TextStyle(color: kMuted, fontSize: 16, height: 1.6),
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100, top: 14),
      itemExtent: 72,
      itemCount: videos.length,
      itemBuilder: (_, i) => _VideoRow(item: videos[i]),
    );
  }
}

class _VideoRow extends StatelessWidget {
  const _VideoRow({required this.item});

  final TrackRef item;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => VideoScreen(item: item))),
      onLongPress: () => showTrackMenu(context, item),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                width: 60,
                height: 60,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    CoverImage(path: item.album.coverPath, cacheWidth: 200),
                    Positioned(
                      left: 5,
                      bottom: 5,
                      child: Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: const Color(0xB3000000),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.play_arrow_rounded, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.track.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 19, height: 1.1)),
                  Text('${item.album.artist}  ·  ${item.album.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, color: kRowMuted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
