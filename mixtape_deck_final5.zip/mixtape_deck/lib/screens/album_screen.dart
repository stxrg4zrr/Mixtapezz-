import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import '../widgets/mini_player.dart';

/// Long-press the cover for more options (play next, queue, edit tags, delete).
/// Long-press a track for its menu.
class AlbumScreen extends StatelessWidget {
  const AlbumScreen({super.key, required this.album});

  final Album album;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pl = context.watch<PlayerController>();
    final refs = store.tracksOf(album);
    final curId = pl.current?.track.id;

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            tooltip: album.pinned ? 'Unpin' : 'Pin to top',
            icon: Icon(album.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                color: kOrange),
            onPressed: () => store.togglePin(album),
          ),
        ],
      ),
      bottomNavigationBar: const SafeArea(top: false, child: MiniPlayer()),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48),
            child: GestureDetector(
              onLongPress: () => showAlbumMenu(context, album,
                  onDeleted: () => Navigator.of(context).maybePop()),
              child: AspectRatio(
                aspectRatio: 1,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CoverImage(path: album.coverPath, cacheWidth: 800),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 4),
            child: Text(album.title,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              '${album.artist}  ·  ${album.tracks.length} tracks',
              style: const TextStyle(color: Colors.white54),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: kOrange,
                  foregroundColor: Colors.black,
                ),
                onPressed: () => pl.playQueue(refs, 0),
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('PLAY', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          ),
          for (var i = 0; i < refs.length; i++)
            ListTile(
              onTap: () => pl.playQueue(refs, i),
              onLongPress: () => showTrackMenu(context, refs[i]),
              leading: SizedBox(
                width: 28,
                child: Center(
                  child: curId == refs[i].track.id
                      ? Icon(pl.playing ? Icons.graphic_eq : Icons.pause,
                          color: kOrange)
                      : Text('${refs[i].track.number}',
                          style: const TextStyle(color: Colors.white54)),
                ),
              ),
              title: Text(
                refs[i].track.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: curId == refs[i].track.id ? kOrange : Colors.white,
                ),
              ),
              trailing: refs[i].track.isVideo
                  ? const Icon(Icons.videocam_outlined, size: 18, color: Colors.white38)
                  : null,
            ),
        ],
      ),
    );
  }
}
