import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:archive/archive_io.dart' hide ZLibDecoder;
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'text_fix.dart';

const _audioExt = {'.mp3', '.m4a', '.wav', '.aac', '.flac', '.ogg'};
const _videoExt = {'.mp4', '.mov', '.m4v'};
const _imageExt = {'.jpg', '.jpeg', '.png'};
const _coverNames = ['cover', 'folder', 'front', 'album', 'artwork'];

class _ZipRejected implements Exception {
  _ZipRejected(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Runs in a background isolate. args = [zipPath, destDir].
/// First tries the fast streaming extractor; if a zip has odd file names
/// (non-UTF-8, very long, ...) it falls back to a lenient built-in extractor.
Future<int> extractZip(List<String> args) async {
  final zipPath = args[0];
  final dest = args[1];
  try {
    return await _extractWithArchive(zipPath, dest);
  } on _ZipRejected {
    rethrow;
  } catch (_) {
    final d = Directory(dest);
    if (d.existsSync()) d.deleteSync(recursive: true);
    d.createSync(recursive: true);
    return _extractLenient(zipPath, dest);
  }
}

Future<int> _extractWithArchive(String zipPath, String dest) async {
  var files = 0;
  final input = InputFileStream(zipPath);
  try {
    final archive = ZipDecoder().decodeBuffer(input);
    for (final f in archive.files) {
      final name = f.name.replaceAll('\\', '/');
      if (name.startsWith('/') ||
          name.split('/').contains('..') ||
          RegExp(r'^[A-Za-z]:').hasMatch(name)) {
        throw _ZipRejected('Unsafe file path inside the zip');
      }
      if (f.isFile) files++;
    }
  } finally {
    await input.close();
  }
  if (files == 0) throw _ZipRejected('That zip is empty');
  await extractFileToDisk(zipPath, dest);
  return files;
}

// ---------------------------------------------------------------------------
// Lenient zip reader (handles any file-name encoding, long names, streams
// every file to disk so big videos never fill the memory).
// ---------------------------------------------------------------------------

class _FileSink implements Sink<List<int>> {
  _FileSink(this.raf);
  final RandomAccessFile raf;
  @override
  void add(List<int> data) => raf.writeFromSync(data);
  @override
  void close() {}
}

int _u16(Uint8List b, int o) => b[o] | (b[o + 1] << 8);
int _u32(Uint8List b, int o) =>
    b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24);

String _decodeName(Uint8List raw) {
  try {
    return utf8.decode(raw);
  } catch (_) {
    return latin1.decode(raw);
  }
}

String _clip(String s, bool isFile) {
  if (utf8.encode(s).length <= 150) return s;
  var ext = '';
  var stem = s;
  if (isFile) {
    final i = s.lastIndexOf('.');
    if (i > 0 && s.length - i <= 8) {
      ext = s.substring(i);
      stem = s.substring(0, i);
    }
  }
  final runes = stem.runes.toList();
  while (runes.isNotEmpty &&
      utf8.encode(String.fromCharCodes(runes)).length > 140) {
    runes.removeLast();
  }
  return String.fromCharCodes(runes) + ext;
}

String? _safeRelative(String name, Set<String> used) {
  final n = name.replaceAll('\\', '/');
  if (n.endsWith('/')) return null; // folder entry
  if (n.contains('__MACOSX')) return null;
  final parts = n.split('/').where((x) => x.isNotEmpty && x != '.').toList();
  if (parts.isEmpty) return null;
  if (parts.contains('..')) throw _ZipRejected('Unsafe file path inside the zip');
  if (parts.last.startsWith('._')) return null;
  for (var i = 0; i < parts.length; i++) {
    parts[i] = _clip(parts[i], i == parts.length - 1);
  }
  var rel = parts.join('/');
  var k = 1;
  while (!used.add(rel.toLowerCase())) {
    final last = parts.last;
    final dot = last.lastIndexOf('.');
    final renamed = dot > 0
        ? '${last.substring(0, dot)}_$k${last.substring(dot)}'
        : '${last}_$k';
    rel = [...parts.sublist(0, parts.length - 1), renamed].join('/');
    k++;
  }
  return rel;
}

int _extractLenient(String zipPath, String dest) {
  final raf = File(zipPath).openSync();
  try {
    final len = raf.lengthSync();
    final tail = math.min(len, 65557);
    raf.setPositionSync(len - tail);
    final tailBytes = Uint8List.fromList(raf.readSync(tail));

    var eocd = -1;
    for (var i = tail - 22; i >= 0; i--) {
      if (tailBytes[i] == 0x50 &&
          tailBytes[i + 1] == 0x4b &&
          tailBytes[i + 2] == 0x05 &&
          tailBytes[i + 3] == 0x06) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw _ZipRejected('Not a valid zip file');

    final total = _u16(tailBytes, eocd + 10);
    final cdSize = _u32(tailBytes, eocd + 12);
    final cdOff = _u32(tailBytes, eocd + 16);
    if (total == 0xFFFF || cdSize == 0xFFFFFFFF || cdOff == 0xFFFFFFFF) {
      throw _ZipRejected('Zip64 archives are not supported');
    }

    raf.setPositionSync(cdOff);
    final cd = Uint8List.fromList(raf.readSync(cdSize));

    final used = <String>{};
    var count = 0;
    var p = 0;
    while (p + 46 <= cd.length && _u32(cd, p) == 0x02014b50) {
      final flags = _u16(cd, p + 8);
      final method = _u16(cd, p + 10);
      final compSize = _u32(cd, p + 20);
      final nameLen = _u16(cd, p + 28);
      final extraLen = _u16(cd, p + 30);
      final commentLen = _u16(cd, p + 32);
      final localOff = _u32(cd, p + 42);
      final nameBytes = Uint8List.sublistView(cd, p + 46, p + 46 + nameLen);
      p += 46 + nameLen + extraLen + commentLen;

      final rel = _safeRelative(_decodeName(nameBytes), used);
      if (rel == null) continue;
      if (flags & 1 != 0) throw _ZipRejected('This zip is password-protected');
      if (method != 0 && method != 8) {
        throw _ZipRejected('Unsupported zip compression');
      }

      raf.setPositionSync(localOff);
      final lh = Uint8List.fromList(raf.readSync(30));
      if (lh.length < 30 || _u32(lh, 0) != 0x04034b50) {
        throw _ZipRejected('Damaged zip file');
      }
      final dataStart = localOff + 30 + _u16(lh, 26) + _u16(lh, 28);

      final outFile = File('$dest/$rel');
      outFile.parent.createSync(recursive: true);
      final out = outFile.openSync(mode: FileMode.write);
      try {
        if (compSize > 0) {
          raf.setPositionSync(dataStart);
          var remaining = compSize;
          if (method == 0) {
            while (remaining > 0) {
              final chunk = raf.readSync(math.min(remaining, 262144));
              if (chunk.isEmpty) throw _ZipRejected('Damaged zip file');
              out.writeFromSync(chunk);
              remaining -= chunk.length;
            }
          } else {
            final conv =
                ZLibDecoder(raw: true).startChunkedConversion(_FileSink(out));
            while (remaining > 0) {
              final chunk = raf.readSync(math.min(remaining, 262144));
              if (chunk.isEmpty) throw _ZipRejected('Damaged zip file');
              conv.add(chunk);
              remaining -= chunk.length;
            }
            conv.close();
          }
        }
      } finally {
        out.closeSync();
      }
      count++;
    }
    if (count == 0) throw _ZipRejected('That zip is empty');
    return count;
  } finally {
    raf.closeSync();
  }
}

T? _try<T>(T? Function() f) {
  try {
    return f();
  } catch (_) {
    return null;
  }
}

class _Entry {
  _Entry(this.file, this.title, this.number);
  final File file;
  final String title;
  final int number;
}

bool _junk(File f) {
  final n = p.basename(f.path);
  return n.startsWith('._') || f.path.contains('__MACOSX');
}

String _titleFromFilename(String path) {
  var t = p.basenameWithoutExtension(path).replaceAll('_', ' ');
  t = t.replaceFirst(RegExp(r'^\d+\s*[.\-]*\s*'), '');
  return t.trim().isEmpty ? p.basenameWithoutExtension(path) : t.trim();
}

String? _pickCover(List<File> images) {
  if (images.isEmpty) return null;
  for (final key in _coverNames) {
    for (final f in images) {
      if (p.basenameWithoutExtension(f.path).toLowerCase().contains(key)) {
        return f.path;
      }
    }
  }
  return images.first.path;
}

/// Runs in a background isolate. args = [destDir, displayName, id].
/// Reads tags + cover and returns the album as JSON.
Map<String, dynamic> scanAlbum(List<String> args) {
  final dest = args[0];
  final displayName = args[1];
  final id = args[2];

  final all = <File>[];
  for (final e in Directory(dest).listSync(recursive: true, followLinks: false)) {
    if (e is File && !_junk(e)) all.add(e);
  }

  final media = all.where((f) {
    final e = p.extension(f.path).toLowerCase();
    return _audioExt.contains(e) || _videoExt.contains(e);
  }).toList()
    ..sort((a, b) => a.path.toLowerCase().compareTo(b.path.toLowerCase()));

  if (media.isEmpty) {
    throw Exception('No playable audio or video files in that zip');
  }

  final images = all
      .where((f) => _imageExt.contains(p.extension(f.path).toLowerCase()))
      .toList();

  final entries = <_Entry>[];
  Uint8List? art;
  String? artistTag;
  String? albumTag;

  for (final f in media) {
    String? title;
    int? no;
    try {
      final dynamic md = readMetadata(f, getImage: art == null);
      title = _try<String>(() => md.title as String?);
      no = _try<int>(() => md.trackNumber as int?);
      final artist = _try<String>(() => md.artist as String?);
      final album = _try<String>(() => md.album as String?);
      title = title == null ? null : fixTagText(title);
      if (artistTag == null && artist != null && fixTagText(artist).isNotEmpty) {
        artistTag = fixTagText(artist);
      }
      if (albumTag == null && album != null && fixTagText(album).isNotEmpty) {
        albumTag = fixTagText(album);
      }
      if (art == null) {
        final pics = _try<List>(() => md.pictures as List?);
        if (pics != null && pics.isNotEmpty) {
          final b = pics.first.bytes;
          if (b is List<int> && b.isNotEmpty) art = Uint8List.fromList(b);
        }
      }
    } catch (_) {}
    entries.add(_Entry(
      f,
      (title != null && title.trim().isNotEmpty)
          ? title.trim()
          : _titleFromFilename(f.path),
      no ?? 0,
    ));
  }

  entries.sort((a, b) {
    final an = a.number == 0 ? 99999 : a.number;
    final bn = b.number == 0 ? 99999 : b.number;
    if (an != bn) return an.compareTo(bn);
    return a.file.path.toLowerCase().compareTo(b.file.path.toLowerCase());
  });

  String? coverPath = _pickCover(images);
  if (coverPath == null && art != null) {
    final cf = File(p.join(dest, 'cover_embedded.jpg'));
    cf.writeAsBytesSync(art);
    coverPath = cf.path;
  }

  final tracks = <Track>[];
  for (var i = 0; i < entries.length; i++) {
    final e = entries[i];
    tracks.add(Track(
      id: '${id}_$i',
      title: e.title,
      path: e.file.path,
      number: i + 1,
      isVideo: _videoExt.contains(p.extension(e.file.path).toLowerCase()),
    ));
  }

  return Album(
    id: id,
    title: albumTag ??
        p.basenameWithoutExtension(displayName).replaceAll('_', ' ').trim(),
    artist: artistTag ?? 'Unknown Artist',
    dirPath: dest,
    coverPath: coverPath,
    tracks: tracks,
  ).toJson();
}

class Importer {
  static Future<Album> importZip(String zipPath, String displayName) async {
    final docs = await getApplicationDocumentsDirectory();
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final dest = p.join(docs.path, 'tapes', id);
    await Directory(dest).create(recursive: true);

    try {
      await compute(extractZip, <String>[zipPath, dest]);
      final json =
          await compute(scanAlbum, <String>[dest, displayName, id]);
      return Album.fromJson(Map<String, dynamic>.from(json));
    } catch (e) {
      try {
        await Directory(dest).delete(recursive: true);
      } catch (_) {}
      rethrow;
    }
  }
}
