import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../screens/edit_album_screen.dart';
import '../screens/video_screen.dart';
import '../theme.dart';

void snack(BuildContext context, String msg) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
}

Widget _tile(IconData icon, String label, VoidCallback onTap, {Color? color}) {
  return ListTile(
    leading: Icon(icon, color: color ?? kOrange),
    title: Text(label),
    onTap: onTap,
  );
}

/// Long-press menu for an album.
Future<void> showAlbumMenu(BuildContext context, Album album,
    {VoidCallback? onDeleted}) async {
  final store = context.read<LibraryStore>();
  final player = context.read<PlayerController>();
  final refs = store.tracksOf(album);

  await showModalBottomSheet<void>(
    context: context,
    builder: (sheet) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _tile(Icons.play_arrow_rounded, 'Play', () {
              Navigator.pop(sheet);
              player.playQueue(refs, 0);
            }),
            _tile(Icons.shuffle_rounded, 'Shuffle', () {
              Navigator.pop(sheet);
              player.playQueue(refs, 0, shuffleOn: true);
            }),
            _tile(Icons.skip_next_rounded, 'Play next', () {
              Navigator.pop(sheet);
              player.playNextMany(refs);
              snack(context, 'Playing next');
            }),
            _tile(Icons.queue_music_rounded, 'Add to queue', () {
              Navigator.pop(sheet);
              player.addManyToQueue(refs);
              snack(context, 'Added to queue');
            }),
            _tile(Icons.playlist_add_rounded, 'Add to playlist', () {
              Navigator.pop(sheet);
              showAddToPlaylist(context, album.tracks.map((t) => t.id).toList());
            }),
            _tile(album.pinned ? Icons.push_pin_outlined : Icons.push_pin,
                album.pinned ? 'Unpin from top' : 'Pin to top', () {
              Navigator.pop(sheet);
              store.togglePin(album);
            }),
            _tile(Icons.edit_outlined, 'Edit tags & cover', () {
              Navigator.pop(sheet);
              Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => EditAlbumScreen(album: album)));
            }),
            _tile(Icons.delete_outline, 'Delete tape', () async {
              Navigator.pop(sheet);
              final ok = await showDialog<bool>(
                context: context,
                builder: (d) => AlertDialog(
                  title: const Text('Delete this tape?'),
                  content: Text(
                      '"${album.title}" and its files will be removed from this phone.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(d, false),
                        child: const Text('Cancel')),
                    TextButton(
                        onPressed: () => Navigator.pop(d, true),
                        child: const Text('Delete',
                            style: TextStyle(color: Colors.redAccent))),
                  ],
                ),
              );
              if (ok == true) {
                await player.stop();
                await store.deleteAlbum(album);
                onDeleted?.call();
              }
            }, color: Colors.redAccent),
          ],
        ),
      ),
    ),
  );
}

/// Menu for one track: play next, add to queue, playlists, favorite.
Future<void> showTrackMenu(BuildContext context, TrackRef r,
    {Playlist? fromPlaylist}) async {
  final store = context.read<LibraryStore>();
  final player = context.read<PlayerController>();
  final fav = store.isFavorite(r.track.id);

  await showModalBottomSheet<void>(
    context: context,
    builder: (sheet) => SafeArea(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(r.track.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
            _tile(Icons.skip_next_rounded, 'Play next', () {
              Navigator.pop(sheet);
              player.playNextMany([r]);
              snack(context, 'Playing next');
            }),
            _tile(Icons.queue_music_rounded, 'Add to queue', () {
              Navigator.pop(sheet);
              player.addManyToQueue([r]);
              snack(context, 'Added to queue');
            }),
            _tile(Icons.playlist_add_rounded, 'Add to playlist', () {
              Navigator.pop(sheet);
              showAddToPlaylist(context, [r.track.id]);
            }),
            _tile(fav ? Icons.favorite : Icons.favorite_border,
                fav ? 'Remove from Favorites' : 'Add to Favorites', () {
              Navigator.pop(sheet);
              store.toggleFavorite(r.track.id);
            }),
            if (r.track.isVideo)
              _tile(Icons.videocam_outlined, 'Watch video', () {
                Navigator.pop(sheet);
                Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => VideoScreen(item: r)));
              }),
            if (fromPlaylist != null)
              _tile(Icons.remove_circle_outline, 'Remove from this playlist', () {
                Navigator.pop(sheet);
                store.removeFromPlaylist(fromPlaylist, r.track.id);
              }, color: Colors.redAccent),
          ],
        ),
      ),
    ),
  );
}

/// Pick a playlist to add tracks to (or make a new one).
Future<void> showAddToPlaylist(BuildContext context, List<String> trackIds) async {
  final store = context.read<LibraryStore>();
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (sheet) => SafeArea(
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Text('Add to playlist',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
            _tile(Icons.add_circle_outline, 'New playlist', () async {
              Navigator.pop(sheet);
              await showPlaylistEditor(context, thenAdd: trackIds);
            }),
            for (final pl in store.playlists)
              ListTile(
                leading: CircleAvatar(
                    radius: 10, backgroundColor: Color(pl.colorValue)),
                title: Text(pl.name),
                subtitle: Text('${pl.trackIds.length} tracks',
                    style: const TextStyle(color: kMuted)),
                onTap: () async {
                  Navigator.pop(sheet);
                  final n = await store.addToPlaylist(pl, trackIds);
                  if (context.mounted) {
                    snack(context,
                        n == 0 ? 'Already in ${pl.name}' : 'Added to ${pl.name}');
                  }
                },
              ),
          ],
        ),
      ),
    ),
  );
}

/// Create or edit a playlist: name, theme color, cover from the gallery.
Future<void> showPlaylistEditor(BuildContext context,
    {Playlist? existing, List<String> thenAdd = const []}) async {
  final store = context.read<LibraryStore>();
  final nameC = TextEditingController(text: existing?.name ?? '');
  var color = existing?.colorValue ?? kPlaylistColorValues.first;
  String? pickedCover;

  final ok = await showDialog<bool>(
    context: context,
    builder: (d) => StatefulBuilder(
      builder: (d, setS) => AlertDialog(
        title: Text(existing == null ? 'New playlist' : 'Edit playlist'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: nameC,
                readOnly: existing?.isFavorites ?? false,
                autofocus: existing == null,
                decoration: const InputDecoration(labelText: 'Name'),
              ),
              const SizedBox(height: 18),
              const Text('Color', style: TextStyle(color: kMuted)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  for (final v in kPlaylistColorValues)
                    GestureDetector(
                      onTap: () => setS(() => color = v),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: Color(v),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: color == v ? Colors.white : Colors.transparent,
                            width: 3,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              TextButton.icon(
                onPressed: () async {
                  final x = await ImagePicker()
                      .pickImage(source: ImageSource.gallery, maxWidth: 1600);
                  if (x != null) setS(() => pickedCover = x.path);
                },
                icon: const Icon(Icons.image_outlined),
                label: Text(pickedCover == null
                    ? 'Cover from gallery'
                    : 'Cover selected'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(d, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(d, true),
              child: const Text('Save')),
        ],
      ),
    ),
  );

  if (ok != true) return;

  Playlist target;
  if (existing == null) {
    target = await store.createPlaylist(nameC.text, color);
  } else {
    await store.updatePlaylist(existing, name: nameC.text, colorValue: color);
    target = existing;
  }
  if (pickedCover != null) await store.setPlaylistCover(target, pickedCover!);
  if (thenAdd.isNotEmpty) {
    await store.addToPlaylist(target, thenAdd);
    if (context.mounted) snack(context, 'Added to ${target.name}');
  }
}
