import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../utils.dart';

/// A-Z + # scroller on the right side of the Tapes list.
class AlphabetBar extends StatelessWidget {
  const AlphabetBar({super.key, required this.onLetter, required this.onEnd});

  final ValueChanged<String> onLetter;
  final VoidCallback onEnd;

  static const letters = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '#',
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final itemH = math.min(15.7, (c.maxHeight - 16) / letters.length);
        final total = itemH * letters.length + 16;

        void handle(double dy) {
          final i = clampInt(((dy - 8) / itemH).floor(), 0, letters.length - 1);
          onLetter(letters[i]);
        }

        return Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (d) => handle(d.localPosition.dy),
            onTapUp: (_) => onEnd(),
            onTapCancel: onEnd,
            onVerticalDragStart: (d) => handle(d.localPosition.dy),
            onVerticalDragUpdate: (d) => handle(d.localPosition.dy),
            onVerticalDragEnd: (_) => onEnd(),
            onVerticalDragCancel: onEnd,
            child: Container(
              width: 32,
              height: total,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xF01C1C1E),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF4A4A4C), width: 1.2),
              ),
              child: Column(
                children: [
                  for (final l in letters)
                    SizedBox(
                      height: itemH,
                      child: Center(
                        child: Text(
                          l,
                          style: TextStyle(
                            fontSize: math.min(12.0, itemH * 0.8),
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                            height: 1.0,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
